import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

const int GRID_SIZE = 25;
const Duration GAME_SPEED = Duration(milliseconds: 200);

void main() {
  runApp(const SnakeGame());
}

class SnakeGame extends StatelessWidget {
  const SnakeGame({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.black,
        body: const GameScreen(),
      ),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({Key? key}) : super(key: key);

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  List<int> snake = [GRID_SIZE * 10, GRID_SIZE * 10 + 1, GRID_SIZE * 10 + 2];
  int food = -1;
  String direction = 'right';
  bool isPlaying = false;
  Timer? _gameTimer;
  int score = 0;
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    resetGame();
    _controller = AnimationController(
      vsync: this,
      duration: GAME_SPEED,
    );
  }

  void startGame() {
    if (isPlaying) return;
    setState(() {
      resetGame();
      isPlaying = true;
      _gameTimer = Timer.periodic(GAME_SPEED, (timer) {
        if (!isPlaying) {
          timer.cancel();
          _gameTimer = null;
        }
        setState(() {
          moveSnake();
          if (checkCollision()) {
            isPlaying = false;
            timer.cancel();
            _gameTimer = null;
            showGameOverDialog();
          }
        });
      });
    });
  }

  void moveSnake() {
    int newHead;

    switch (direction) {
      case 'up':
        newHead = snake.last - GRID_SIZE;
        break;
      case 'down':
        newHead = snake.last + GRID_SIZE;
        break;
      case 'left':
        newHead = snake.last - 1;
        break;
      case 'right':
        newHead = snake.last + 1;
        break;
      default:
        return;
    }

    if (snake.contains(newHead)) {
      isPlaying = false;
      _gameTimer?.cancel();
      showGameOverDialog();
      return;
    }

    setState(() {
      snake.add(newHead);
      if (snake.last == food) {
        score++; // Increment the score
        generateFood();
      } else {
        snake.removeAt(0);
      }

      _controller.forward(from: 0); // Animate the snake’s movement
    });
  }

  void generateFood() {
    Random random = Random();
    List<int> validPositions = List.generate(GRID_SIZE * GRID_SIZE, (i) => i)
        .where((pos) => !snake.contains(pos))
        .toList();

    if (validPositions.isNotEmpty) {
      food = validPositions[random.nextInt(validPositions.length)];
    } else {
      isPlaying = false;
      _gameTimer?.cancel();
      showGameOverDialog();
    }
  }

  bool checkCollision() {
    int head = snake.last;

    if (head < 0 || head >= GRID_SIZE * GRID_SIZE) {
      return true;
    }

    if (direction == 'left' && head % GRID_SIZE == GRID_SIZE - 1) {
      return true;
    }

    if (direction == 'right' && head % GRID_SIZE == 0) {
      return true;
    }

    return false;
  }

  void showGameOverDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.black,
          title: const Text(
            "Game Over",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            "Your score was $score. Try again?",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                startGame();
              },
              child: const Text(
                "Yes",
                style: TextStyle(
                  color: Colors.green,
                  fontSize: 18,
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text(
                "No",
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 18,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void resetGame() {
    setState(() {
      snake = [GRID_SIZE * 10, GRID_SIZE * 10 + 1, GRID_SIZE * 10 + 2];
      direction = 'right';
      generateFood();
      isPlaying = false;
      score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    const double cellSize = 25.0;
    final double gridSize = cellSize * GRID_SIZE;

    return GestureDetector(
      onVerticalDragUpdate: (details) {
        if (details.delta.dy < 0 && direction != 'down') {
          direction = 'up';
        } else if (details.delta.dy > 0 && direction != 'up') {
          direction = 'down';
        }
      },
      onHorizontalDragUpdate: (details) {
        if (details.delta.dx < 0 && direction != 'right') {
          direction = 'left';
        } else if (details.delta.dx > 0 && direction != 'left') {
          direction = 'right';
        }
      },
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Scoreboard at the top
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Score: $score",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Flexible(
              child: Container(
                width: gridSize,
                height: gridSize,
                decoration: BoxDecoration(
                  color: Colors.black,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: Stack(
                  children: [
                    // Snake segments
                    ...List.generate(snake.length, (index) {
                      final snakeSegment = snake[index];
                      final x = (snakeSegment % GRID_SIZE) * cellSize;
                      final y = (snakeSegment ~/ GRID_SIZE) * cellSize;

                      return AnimatedPositioned(
                        left: x,
                        top: y,
                        duration: GAME_SPEED,
                        child: Container(
                          width: cellSize,
                          height: cellSize,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.green.shade700, Colors.green.shade400],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      );
                    }),

                    // Food
                    if (food != -1)
                      Positioned(
                        left: (food % GRID_SIZE) * cellSize,
                        top: (food ~/ GRID_SIZE) * cellSize,
                        child: Container(
                          width: cellSize,
                          height: cellSize,
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              colors: [Colors.red, Colors.orange],
                              center: Alignment.center,
                              radius: 0.8,
                            ),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: isPlaying ? null : startGame,
                style: ElevatedButton.styleFrom(
                  primary: Colors.green,
                  onPrimary: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  elevation: 8,
                  shadowColor: Colors.green.withOpacity(0.5),
                ),
                child: const Text(
                  "Start Game",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
